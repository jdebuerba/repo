import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

public class Town extends Object implements Comparable<Town>{

	private String townName;
	List<Town> nearbyTowns;
	
	public Town(String name) {
		townName = name;
		nearbyTowns = new ArrayList<Town>();
	}
	
	public Town(Town town) {
		this(town.getName());
		nearbyTowns = new ArrayList<Town>(town.nearbyTowns);	
	}
	
	@Override
	public int compareTo(Town o) {
		return this.townName.compareToIgnoreCase(o.getName());	
	}

	public String getName() {
		return townName;
	}

	public void setTown(String townName) {
		this.townName = townName;
	}

	public List<Town> getNearbyTowns() {
		return nearbyTowns;
	}

	public void setNearbyTowns(ArrayList<Town> towns) {
		for (int i = 0; i < towns.size(); i++) {
			nearbyTowns.add(towns.get(i));
		}
	}
	
	public void addNearbyTown(Town town) {
		nearbyTowns.add(town);
	}
	
	public int hashCode() {
		return townName.hashCode();
	}
	
	public String toString() {
		String towns = "";
		for (int i = 0; i < nearbyTowns.size(); i++) {
			towns += nearbyTowns.get(i).getName() + " ";
		}
		return "Town: "+townName+" Neigbouring Towns: "+towns+"\n";
	}
	
	public boolean equals(Object obj) {
		Town town = (Town) obj;
		if(townName.equalsIgnoreCase(town.getName()))
			return true;
		else
			return false;
	}
}
