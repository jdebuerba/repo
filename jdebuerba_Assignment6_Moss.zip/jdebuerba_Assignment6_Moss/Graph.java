import java.util.ArrayList;
import java.util.Stack;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.Comparator;

public class Graph implements GraphInterface<Town, Road>{

	private ArrayList<Town> towns;
	private ArrayList<Road> roads;
	private ArrayList<String> shortestPath;
	
	public Graph() {
		towns = new ArrayList<Town>();
		roads = new ArrayList<Road>();
		shortestPath = new ArrayList<>();
	}

	@Override
	public Road getEdge(Town sourceVertex, Town destinationVertex) {
		for(Road edge : roads) {
			if(edge.getSource().equals(sourceVertex) && edge.getDestination().equals(destinationVertex)) 
				return edge;
			else if(edge.getDestination().equals(sourceVertex) && edge.getSource().equals(destinationVertex))
				return edge;
		}
		return null;
	}

	@Override
	public Road addEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
		Road edge = new Road(sourceVertex,destinationVertex,weight,description);
		roads.add(edge);
		return edge;
	}

	@Override
	public boolean addVertex(Town v) {
		for(Town vertex : towns) {
			if(v.equals(vertex)) 
				return false;
		}
		towns.add(v);
		return true;
	}

	@Override
	public boolean containsEdge(Town sourceVertex, Town destinationVertex) {
		for(Road edge : roads) {
			if(edge.contains(destinationVertex) && edge.contains(destinationVertex))
				return true;
		}
		return false;
	}

	@Override
	public boolean containsVertex(Town v) {
		for(Town vertex : towns) {
			if(vertex.equals(v))
				return true;
		}
		return false;
	}

	@Override
	public Set<Road> edgeSet() {
		HashSet<Road> edges = new HashSet<>();
		for(Road road : roads) {
			edges.add(road);
		}
		return edges;
	}

	@Override
	public Set<Road> edgesOf(Town vertex) {
		HashSet<Road> edges = new HashSet<>();
		for(Road road : roads) {
			if(road.contains(vertex))
				edges.add(road);
		}
		return edges;
	}

	@Override
	public Road removeEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
		Road removedEdge = null;
		for(Road road : roads) {
			if (road.contains(sourceVertex) && road.contains(destinationVertex)) {
				if (road.getWeight() == weight) { 
					if(road.getName().equals(description)){
						removedEdge = road;
						roads.remove(road);
						break;
					}
				}
			}
		}
		return removedEdge;
	}

	@Override
	public boolean removeVertex(Town v) {
		if(towns.contains(v)) {
			towns.remove(v);
			return true;
		}
		return false;
	}

	@Override
	public Set<Town> vertexSet() {
		HashSet<Town> vertices = new HashSet<>();
		for(Town town : towns) {
			vertices.add(town);
		}
		return vertices;
	}

	 public ArrayList<String> shortestPath(Town sourceVertex, Town destinationVertex) {
		 ArrayList<String> result = new ArrayList<String>();
		return result;

	}


	public void dijkstraShortestPath(Town sourceVertex) {
		 }  
}