
public class Road extends Object implements Comparable<Road> {

	Town source;
	Town destination;
	int distance;
	String roadName;
	
	public Road(Town source, Town destination, int degrees, String name) {
		this.source = source;
		this.destination = destination;
		this.distance = degrees;
		this.roadName = name;
	}
	
	public Road(Town source, Town destination, String name) {
		this(source,destination,1,name);
	}
	
	public boolean contains(Town town) {
		if(source.getName().equalsIgnoreCase(town.getName()) || destination.getName().equalsIgnoreCase(town.getName())) 
			return true;
		else
			return false;
	}
	
	public String toString() {
		return "Road Name: "+roadName+" Start: "+source+" Destination: "+destination+"\n"; 
	}
	
	@Override
	public int compareTo(Road o) {
		return roadName.compareToIgnoreCase(o.getName());
	}

	public Town getSource() {
		return source;
	}

	public void setSource(Town source) {
		this.source = source;
	}

	public Town getDestination() {
		return destination;
	}

	public void setDestination(Town destination) {
		this.destination = destination;
	}

	public int getWeight() {
		return distance;
	}

	public void setWeight(int distance) {
		this.distance = distance;
	}

	public String getName() {
		return roadName;
	}

	public void setRoadName(String roadName) {
		this.roadName = roadName;
	}
	
	public boolean equals(Object r) {
		Road road = (Road) r;
		if(road.getSource().equals(source) && road.getDestination().equals(destination))
			return true;
		else if(road.getSource().equals(destination) && road.getDestination().equals(source))
			return true;
		else
			return false;
	}
}
	


