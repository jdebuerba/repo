/**
 * Acts as a node that holds some kind of data.
 * Each node references 2 child nodes, left and right.
 * @author jose de buerba
 *
 * @param <T>
 */
public class TreeNode<T> {
	private T data;
	TreeNode<T> left;
	TreeNode<T> right;
		
	/**
	 * Node constructor with data argument
	 * @param data
	 */
	public TreeNode(T data) {
		this.data = data;
		left = null;
		right = null;
	}
	
	/**
	 * Node constructor that copies an existing node
	 * @param node
	 */
	public TreeNode(TreeNode<T> node) {
		this(node.data);
	}
	
	/**
	 * Returns the data attribute value
	 * @return
	 */
	public T getData() {
		return data;
	}
	
	public TreeNode<T> getLeft() {
		return left;
	}
	
	public TreeNode<T> getRight() {
		return right;
	}

	public void setLeft(TreeNode<T> node) {
		left = node;
	}
	
	public void setRight(TreeNode<T> node) {
		right = node;
	}
}
