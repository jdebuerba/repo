import java.util.ArrayList;
/**
 * This is a MorseCodeTree which is specifically used for the conversion of morse code to english
It relies on a root (reference to root of the tree)
The root is set to null when the tree is empty.
The class uses an external generic TreeNode class which consists of a reference to the data and a reference to the left and right child. The TreeNode is parameterized as a String, TreeNode This class uses a private member root (reference to a TreeNode)
The constructor will call the buildTree
 * @author Jose de Buerba

 */

public class MorseCodeTree implements LinkedConverterTreeInterface<String>{
	
	private TreeNode<String> root;
	
	/**
	 * Default constructor calls buildTree() method
	 */
	public MorseCodeTree() {
		root = null;
		buildTree();
	}
	
	/**
	 * Returns a reference to the root
	 * @return root reference to the root
	 */
	@Override
	public TreeNode<String> getRoot() {
		return root;
	}
	
	/**
	 * Sets the root of the MorseCodeTree
	 * @param newNode sets the value of root
	 */
	@Override
	public void setRoot(TreeNode<String> newNode) {
		root = new TreeNode<String>(newNode);	
	}

	/**
	 * Adds element to the correct position in the tree based on the code This method will call the recursive method addNode
	 * @param code letter in morse code
	 * @param letter letter that's added
	 */
	@Override
	public void insert(String code, String letter) {
		if(root == null){
			root = new TreeNode<String>(letter);
		}
		//Call recursive addNode() method
		else {
			addNode(root,code,letter);
		}
	}

	/**
	 * This is a recursive method that adds element to the correct position in the tree based on the code
	 * @param root or subtree in tree
	 * @param code letter in morse
	 * @param letter letter thats added
	 */
	@Override
	public void addNode(TreeNode<String> root, String code, String letter) {
		//Compare . vs -
		if(code.length() > 1) {
			if(code.charAt(0) == '.') 	
				addNode(root.getLeft(),code.substring(1),letter);
			else 
				addNode(root.getRight(),code.substring(1),letter);
		}
		else {
			if(code.equals("-")) 
				root.setRight(new TreeNode<String>(letter));
			else 
				root.setLeft(new TreeNode<String>(letter));
		}
	}

	/**
	 * Fetch the data in the tree based on the code This method will call the recursive method fetchNode
	 * @param code letter in morse
	 * @return code representing a string
	 */
	@Override
	public String fetch(String code) {
		return fetchNode(root,code);
	}

	/**
	 * This is the recursive method that fetches the data of the TreeNode that corresponds with the code 
	 * @param root or subtree in tree
	 * @param code letter in morse
	 * @return code representing a string 
	 */
	@Override
	public String fetchNode(TreeNode<String> root, String code) {
		String letter = "";
		if(code.length() > 1) {
			if(code.charAt(0) == '.') 
				letter += fetchNode(root.getLeft(),code.substring(1));
			else 
				letter += fetchNode(root.getRight(),code.substring(1));
		}
		else {
			if(code.equals("-")) 
				return letter += root.getRight().getData();
			else 
				return letter += root.getLeft().getData();
		}
		return letter;
	}

	/**
	 * This operation is not supported in the MorseCodeTree
	 * @throws UnsupportedOperationException 
	 * @param data from node to be deleted
	 * @return reference to the current tree
	 */
	@Override
	public MorseCodeTree delete(String data) throws UnsupportedOperationException {
		throw new UnsupportedOperationException();
	}

	/**
	 * This operation is not supported in the MorseCodeTree
	 * @throws UnsupportedOperationException 
	 * @return reference to the current tree
	 */
	@Override
	public MorseCodeTree update() throws UnsupportedOperationException {
		throw new UnsupportedOperationException();
	}

	/**
	 * This method builds the MorseCodeTree by inserting the nodes of the tree level by level based on the code
	 */
	@Override
	public void buildTree() {
		insert("","");
		insert(".","e"); 
		insert("-","t");
		insert("..","i"); 
		insert(".-","a");
		insert("-.","n"); 
		insert("--","m");
		insert("...","s"); 
		insert("..-","u");
		insert(".-.","r"); 
		insert(".--","w");
		insert("-..","d");
		insert("-.-","k");
		insert("--.","g");
		insert("---","o");
		insert("....","h"); 
		insert("...-","v");
		insert("..-.","f"); 
		insert(".-..","l");
		insert(".--.","p"); 
		insert(".---","j");
		insert("-...","b"); 
		insert("-..-","x");
		insert("-.-.","c"); 
		insert("-.--","y");
		insert("--..","z"); 
		insert("--.-","q");	
	}

	/**
	 * Returns an ArrayList of the items in the linked Tree in LNR (Inorder) Traversal order Used for testing to make sure tree is built correctly
	 * @return arrayList of items in the tree 
	 */
	@Override
	public ArrayList<String> toArrayList() {
		ArrayList<String> list = new ArrayList<String>();
		LNRoutputTraversal(root,list);
		return list;
	}

	/**
	 * The recursive method to put the contents of the tree in an ArrayList in LNR (Inorder)
	 * @param root or subtree in tree
	 * @param arraylist to store all letters 
	 */
	@Override
	public void LNRoutputTraversal(TreeNode<String> root, ArrayList<String> list) {
		if(root.getLeft() == null && root.getRight() == null) 
			list.add(root.getData());
		else {
			if(root.getLeft() != null) {
				LNRoutputTraversal(root.getLeft(),list);
				list.add(root.getData( ));
			}
			if(root.getRight() != null) 
				LNRoutputTraversal(root.getRight(),list);	
		}
	}
	
}