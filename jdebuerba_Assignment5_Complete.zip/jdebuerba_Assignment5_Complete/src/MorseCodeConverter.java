import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Class will print the tree containing the morse data, a method to translate the morse code to english language
 * @author Jose de Buerba
 *
 */
public class MorseCodeConverter {
	static MorseCodeTree tree = new MorseCodeTree();
	
	/**
	 * returns a string with all the data in the tree in LNR order with an space in between them.
	 * @return data
	 */
	public static String printTree() {
		String data = "";
		for(String element : tree.toArrayList()) {
			data += element + " ";
		}
		return data;
	}
	
	/**
	 * Converts a morse code into english. " " represents a new letter and "/" represents a new word
	 * @param code morse code to be translated
	 * @return translation of morse code
	 */
	public static String convertToEnglish(String code) {
		String translation = "";
		String[] codeArray = code.split(" ");
		for(String letters : codeArray) {
			if(letters.equals("/")) {
				translation += " ";
				continue;
			}
			translation += tree.fetch(letters);
		}
		return translation;
	}
	
	/**
	 * Converts a file from morse code to english. Each line is read by scanner and translated by other convertToEnglish method
	 * @param codeFile file containing morse code
	 * @throws FileNotFoundException 
	 * @return translation of morse code file 
	 */
	public static String convertToEnglish(File codeFile) throws FileNotFoundException {
		if(!codeFile.exists()) {
			throw new FileNotFoundException("File does not exist");
		}
		String translation = "";
		Scanner read = new Scanner(codeFile);
		while(read.hasNext()) {
			translation += convertToEnglish(read.nextLine());
		}
		read.close();
		return translation;
	}
}