package package1;

import java.util.*;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The PasswordCheckerUtility class will have at least three public methods that check whether a given String(password)
 * is a valid password, a weak password, or a invalid password
 * @author jdebuerba
 *
 */
public class PasswordCheckerUtility {

	/**
	 * Compares the equality(case-sensitive)of two passwords(strings) 
	 * @param password first password string that is checked for
	 * @param passwordConfirm second password string that checks against the first password
	 * @throws UnmatchedException thrown if not the same(case-sensitive)
	 */
	public static void comparePasswords(String password, String passwordConfirm) throws UnmatchedException{
			if(!password.equals(passwordConfirm)) //Checks if both strings are equal 
				throw new UnmatchedException(); 
	}
	
	/**
	 * Compares the equality(case-sensitive)of two passwords(Strings) and returns true if equal or false if not
	 * @param password first password string that is checked for
	 * @param passwordConfirm second password string that checks against the first password
	 * @return true if passwords are same(case-sensitive) and false otherwise
	 */
	public static boolean comparePasswordsWithReturn(String password, String passwordConfirm) {
		if(password.equals(passwordConfirm)) 
			return true; //Return true if passwords are equal
		else
			return false; //Return false if passwords are not equal
	}
	
	/**
	 * Checks password string to see if it meets the required length(>=6)
	 * @param password string checked for length
	 * @return true if the length of password is >=6
	 * @throws LengthException thrown if string does not meet required length
	 */
	public static boolean isValidLength(String password)throws LengthException{
			if(password.length() < 6) 
				throw new LengthException();
			else 
				return true; //Return true if password length is greater than 6 or equal to
	}
	/**
	 * Checks the password string to see if it contains at least one upper case letter
	 * @param password string checked for upper case letter
	 * @return true if password contains a upper case letter
	 * @throws NoUpperAlphaException thrown if the password does not contain a upper case letter
	 */
	public static boolean hasUpperAlpha​(String password) throws NoUpperAlphaException{
		char[] passwordArray = password.toCharArray(); //Turns password into an array of characters
		
		for(char ch:passwordArray) {  //Iterate through the password to find an upper case letter
			if(Character.isUpperCase(ch)) {
				return true;
			}
		}
		throw new NoUpperAlphaException(); 
	}
	
	/**
	 * Checks the password string to see if it contains at least one lower case letter
	 * @param password string checked for lower case letter
	 * @return true if password contains a lower case letter
	 * @throws NoLowerAlphaException thrown if the password does not contain a lower case letter
	 */
	public static boolean hasLowerAlpha​(String password) throws NoLowerAlphaException{
		char[] passwordArray = password.toCharArray();  //Turns password into an array of characters
		
		for(char ch:passwordArray) {
			if(Character.isLowerCase(ch)) {  //Iterate through the password to find an lower case letter
				return true;
			}
		}
		throw new NoLowerAlphaException();  
	}
	
	/**
	 * Checks the password string for numeric characters
	 * @param password string checked for digits
	 * @return true if password contains a digit
	 * @throws NoDigitException thrown if password does not contain a digit
	 */
	public static boolean hasDigit​(String password) throws NoDigitException{
		char[] passwordArray = password.toCharArray(); //Turns password into an array of characters
		
		for(char ch:passwordArray) {  //Iterate through the password to find an digit
			if(Character.isDigit(ch)){
				return true;
			}
		}
		throw new NoDigitException(); 
	}
	
	/**
	 * Checks the password string for special characters such as, "@#$%"
	 * @param password string checked for containing a special character
	 * @return true if password contains a special character
	 * @throws NoSpecialCharacterException thrown if password doesnt contain a special character
	 */
	public static boolean hasSpecialChar​(String password) throws NoSpecialCharacterException{
		char[] passwordArray = password.toCharArray(); //Turns password into an array of characters
		
		for(int i = 0;i < passwordArray.length; i++) { //Loop through password characters to find special character
            if (!Character.isDigit(passwordArray[i]) && !Character.isLetter(passwordArray[i]) && !Character.isWhitespace(passwordArray[i])) //If the character at the index is not a digit,letter,or whitespace return true
            	return true;
		}
		throw new NoSpecialCharacterException();		
	}
	
	/**
	 * Checks the password string for a sequence of characters, password should not contain more than two of the same characters
	 * @param password string checked for the sequence requirement 
	 * @return true if password meets the valid sequence
	 * @throws InvalidSequenceException thrown if more than two characters in a sequence
	 */
	public static boolean NoSameCharInSequence​(String password) throws InvalidSequenceException{
		for (int i = 0; i < password.length() - 2; i++){  //Loop through password string
			if((password.charAt(i) == password.charAt(i + 1)) && (password.charAt(i) == password.charAt(i+2))) { //Each character in the password string is tested for a sequence of the same character and throws an exception if the sequence is greater than two 
				throw new InvalidSequenceException();
			}
		}
		return true; //Return true if proper sequence is present in the password
	}
	
	/**
	 * Checks if given password is valid in that: 1. is at least 6 characters long - 2. is at least 1 numeric character- 3. is at least 1 uppercase alphabetic character 
	 * 4. is at least 1 lowercase alphabetic character - 5. is at least 1 special character - 6. is no more than 2 of the same character in a sequence 
	 * @param password string checked for validity
	 * @return true if password meets all requirements
	 * @throws LengthException thrown if password is less than 6 characters
	 * @throws NoUpperAlphaException thrown if password has no upper case letters
	 * @throws NoLowerAlphaException thrown if password has no lower case letters
	 * @throws NoDigitException thrown if password contains no digits
	 * @throws NoSpecialCharacterException thrown if password contains no special characters
	 * @throws InvalidSequenceException thrown if password has more than 2 of the same character
	 */
	public static boolean isValidPassword​(String password) throws LengthException, NoUpperAlphaException, NoLowerAlphaException, NoDigitException, NoSpecialCharacterException, InvalidSequenceException{
		//Test all the methods of PasswordCheckerUtility and catch each custom exception
		try{ 
			isValidLength(password);
			hasDigit​(password);
			hasUpperAlpha​(password);
			hasLowerAlpha​(password);
			hasSpecialChar​(password);
			NoSameCharInSequence​(password);
			
		}catch(LengthException ex) {
			throw new LengthException();
		}catch(NoUpperAlphaException ex) {
			throw new NoUpperAlphaException();
		}catch(NoLowerAlphaException ex) {
			throw new NoLowerAlphaException();
		}catch(NoDigitException ex) {
			throw new NoDigitException();
		}catch(NoSpecialCharacterException ex) {
			throw new NoSpecialCharacterException();
		}catch(InvalidSequenceException ex) {
			throw new InvalidSequenceException();
		}
		return true; //Returns true if no exceptions or violations occurred
	}
	
	/**
	 * Checks if the password string has between 6 and 9 (both inclusive) characters
	 * @param password string tested for length requirements
	 * @return true if password has between 6 and 9 characters
	 */
	public static boolean hasBetweenSixAndNineChars​(String password) {
		if(password.length() >= 6 && password.length() <= 9) 
			return true;
		else
			return false;
	}
	
	/**
	 * Checks if password string is a weak password
	 * @param password string tested for security weakness
	 * @return false if password is not weak, greater than 10 characters
	 * @throws WeakPasswordException thrown when password is weak, between 6 and 9 characters
	 */
	public static boolean isWeakPassword​(String password) throws WeakPasswordException{
		if(hasBetweenSixAndNineChars​(password)) { //Uses the former method, hasBetweenSixAndNineChars​, to check if password is weak
			throw new WeakPasswordException(); //Thrown if password is weak but acceptable
		}else {
			return false;
		}
	}
	
	public static ArrayList<String> getInvalidPasswords​(ArrayList<String> passwords){
		ArrayList<String> invalidPasswords= new ArrayList<String>();  //Arraylist will contain all passwords that are not valid with their caught exceptions
		for (String s:passwords){ //Iterate through all passwords in arraylist parameter
			
			try { //Test for password validity
				isValidPassword​(s);
			}
			catch(Exception ex) { //Add the invalid password on to an arraylist of invalid passwords, concatenate the reason why the password is invalid 
				invalidPasswords.add(s.concat(": ").concat(ex.getMessage()));
			}
		}
		return invalidPasswords; //Return an arraylist of invalid passwords
	}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	
	

