
/**
 * CourseDBElement implements Comparable interface and consists of five attributes: 
 * the Course ID (a String), the CRN (an int), the number of credits (an int), the room number (a String), and the instructor name (a String).   
 * Normally the CourseDBElement will be an object consisting of these five attributes and is referred to as a CDE.
 * @author jose de buerba
 *
 */
public class CourseDBElement implements Comparable {
	//Element attributes
	private String ID;
	private int CRN;
	private int credits;
	private String room;
	private String name;
	
	//Constructor that assigns all five attributes
	public CourseDBElement(String ID,int CRN,int credits,String room,String name) {
		this.ID = ID;
		this.CRN = CRN;
		this.credits = credits;
		this.room = room;
		this.name = name;
	}
	
	//Default constructor 
	public CourseDBElement() {
		this.ID = null;
		this.CRN = 0;
		this.credits = 0;
		this.room = null;
		this.name = null;
	}
	
	/**
	 * Sets course ID
	 * @param ID
	 */
	public void setID(String ID) {
		this.ID = ID;
	}
	
	/**
	 * Set course crn
	 * @param CRN
	 */
	public void setCRN(int CRN) {
		this.CRN = CRN;
	}
	
	/**
	 * Set course credits
	 * @param credits
	 */
	public void setCredits(int credits) {
		this.credits = credits;
	}
	
	/**
	 * Set course room number
	 * @param room
	 */
	public void setRoomNum(String room) {
		this.room = room;
	}
	
	/**
	 * Set instructor name
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Get course ID
	 * @return course ID
	 */
	public String getID() {
		return ID;
	}
	
	/**
	 * Get course crn
	 * @return crn
	 */
	public int getCRN() {
		return CRN;
	}
	
	/**
	 * Get course credits
	 * @return
	 */
	public int getCredits() {
		return credits;
	}
	
	/**
	 * Get course room number
	 * @return room
	 */
	public String getRoomNum() {
		return room;
	}
	
	/**
	 * Get instructor name
	 * @return name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Calculates the crn(as a string) hashcode 
	 * @return
	 */
	public int getHashcode() {
		String hash = Integer.toString(getCRN());
		return hash.hashCode();	
	}
	
	/**
	 * Returns all the course information on one line
	 */
	public String toString() {
		return "Course: " + getID() + " CRN: " + getCRN() + " Credits: " + getCredits() + " Instructor: " + getName() + " Room: " + getRoomNum();
	}
	//Course:CMSC600 CRN:4000 Credits:4 Instructor:Somebody Room:SC200
	
	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}

}
