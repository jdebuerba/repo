import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Implements the CourseDBManagerInterface that is provided.
The data manager allows the user to read the courses from a file or to enter the data by hand and uses an Alert to print out the database elements.
 The input is read from a file or read from the textfields and is added to the data structure through the add method.  
 The add method uses the CDS ‘s add method. The CourseDBManager is also referred to as a CDM.

 * @author jose de buerba
 *
 */
public class CourseDBManager implements CourseDBManagerInterface {
	CourseDBStructure database = new CourseDBStructure(50);

	/**
	 * Adds a course (CourseDBElement) with the given information
	 * to CourseDBStructure.
	 * @param id course id 
	 * @param crn course crn
	 * @param credits number of credits
	 * @param roomNum course room number
	 * @param instructor name of the instructor
	 */
	@Override
	public void add(String id, int crn, int credits, String roomNum, String instructor) {
		CourseDBElement newElement = new CourseDBElement(id, crn, credits, roomNum, instructor);
		database.add(newElement);
		
	}
	
	/**
	 * finds  CourseDBElement based on the crn key
	 * @param crn course crn (key)
	 * @return a CourseDBElement object
	 * 
	 */
	@Override
	public CourseDBElement get(int crn) {
			try {
				//return dbs get() method
				return database.get(crn);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return null;
	}
	
	/**
	 * Reads the information of courses from a test file and adds them
	 * to the CourseDBStructure data structure
	 * @param input input file 
	 * @throws FileNotFoundException if file does not exists
	 */
	@Override
	public void readFile(File input) throws FileNotFoundException {
		//File scanner object
		Scanner scan = new Scanner(input);
		//Reader to get output used with scanner 
		String read;
		if(!input.exists()) {
			scan.close();
			throw new FileNotFoundException("File does not exist or could not be found");
		}
		while (scan.hasNextLine()) {
			//Current line from txt file
			read = scan.nextLine();
			
			//Create array containing course info starting from course id @ index 0 and @ index 4 the instructor 
			String[] courseInfo = read.split(" ", 5);
			
			//Initialize course name,crn,credits,room number,and instructor
			String ID = courseInfo[0];
			int crn = Integer.parseInt(courseInfo[1]);
			int credits = Integer.parseInt(courseInfo[2]);
			String roomNum = courseInfo[3];
			String instructor = courseInfo[4];
			
			//Create database element from course info on txt file
			CourseDBElement newElement = new CourseDBElement(ID,crn,credits,roomNum,instructor);
			//Add database element to the database 
			database.add(newElement);
		}
		//Close file scanner
		scan.close();
	}
	
	/**
	 * @return an array list of string representation of each course in 
	 * the data structure separated by a new line. 
	 * Refer to the following example:
	 * Course:CMSC500 CRN:39999 Credits:4 Instructor:Nobody InParticular Room:SC100
	 * Course:CMSC600 CRN:4000 Credits:4 Instructor:Somebody Room:SC200
	 */
	@Override
	public ArrayList<String> showAll() {
		//Return DBS showall() method
		return database.showAll();
	}
}