import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Referred as CDS, Implements the CourseDBStructureInterface that is provided.
You will be implementing a hash table with buckets. 
Each bucket will be an array of linked lists of CourseDBElements.  
Each CourseDBElement object will have a hash code that is calculate based on the CRN, since the CRN is unique for courses.  
 * @author jose de buerba
 *
 */
public class CourseDBStructure implements CourseDBStructureInterface {
	LinkedList<CourseDBElement>[] hashtable;
	int size;
	
	//Constructor creates a hashtable with a size of the int parameter
	@SuppressWarnings("unchecked")
	public CourseDBStructure(int n) {
		size = n;
		hashtable = new LinkedList[n];
	}
	
	//Constructor creates a hashtable with a size of the int parameter and also a string parameter
	@SuppressWarnings("unchecked")
	public CourseDBStructure(String Testing, int n) {
		size = n;
		hashtable = new LinkedList[n];
	}
	
	//No argument constructor creates a hashtable with default size of 50
	@SuppressWarnings("unchecked")
	public CourseDBStructure() {
		size = 50;
		hashtable = new LinkedList[50];
	}
	
	/** 
	* Adds a CourseDBElement object to the CourseDBStructure using the hashcode
	* of the CourseDatabaseElemen object's crn value.
	* If the CourseDatabaseElement already exists, exit quietly
	*  
	* @param element the CourseDBElement to be added to CourseDBStructure
	*/
	@Override
	public void add(CourseDBElement element) {
		//Hashed index used to search for bucket in database
		int index = element.getHashcode()%size; 
		//Create a linkedlist with hashcode and add element
		if(hashtable[index] == null) {
			hashtable[index] = new LinkedList<CourseDBElement>();
			hashtable[index].add(element);
		}
		//If linkedlist bucket with index hashcode exists, then check if course exists(with crn) and soft return if it does
		else {
			for(CourseDBElement elements : hashtable[index]) {
				if(elements.getCRN() == element.getCRN()) {
					return;
				}
			}
			//Add data element to database if bucket exists and no duplicate
			hashtable[index].add(element);
		}
		
	}

	/**
	 * Find a courseDatabaseElement based on the key (crn) of the
	 * courseDatabaseElement If the CourseDatabaseElement is found return it If not,
	 * throw an IOException
	 * 
	 * @param crn crn (key) whose associated courseDatabaseElement is to be returned
	 * @return a CourseDBElement whose crn is mapped to the key
	 * @throws IOException if key is not found
	 */
	@Override
	public CourseDBElement get(int crn) throws IOException {
		//Hashed index used to search for bucket in database
		int index = getHashcode(crn)%size;
		//If bucket with specific index is null throw IOException
		if(hashtable[index] == null) {
			throw new IOException("Course doesn't exist or could not be found");
		}
		//Iterate through all elements in database to find specific element using its crn and then return it
		for(CourseDBElement element : hashtable[index]) {
			if(element.getCRN() == crn) {
				return element;
			}
		}
		//Base return
		throw new IOException("Course doesn't exist"); 
	}

	/**
	 * @return an array list of string representation of each course in 
	 * the data structure separated by a new line. 
	 * Refer to the following example:
	 * Course:CMSC500 CRN:39999 Credits:4 Instructor:Nobody InParticular Room:SC100
	 * Course:CMSC600 CRN:4000 Credits:4 Instructor:Somebody Room:SC200
	 */
	@Override
	public ArrayList<String> showAll() {
		//List containing all of the courses names, crns, credits, instructors,and room numbers
		ArrayList<String> list = new ArrayList<String>();
		//Iterate through all buckets in database
		for(LinkedList<CourseDBElement> linkedlist : hashtable) {
			//If bucket/index contains something or is not null
			if(linkedlist != null) {
				//Iterate through all data elements in the buckets if more than 0
				for(CourseDBElement element : linkedlist) {
					//Add the course to the list
					list.add(element.toString());
				}
			}
		}
		//return the list
		return list;
	}

	/**
	* Returns the size of the DataStructure (number of indexes in the array)
	*/
	@Override
	public int getTableSize() {
		// TODO Auto-generated method stub
		return size;
	}
	
	/**
	 * Finds the hashcode of the crn by converting it from an int to a String then 
	 * finding the hashcode of that String to be used as an index in the database
	 * @param CRN course crn number
	 * @return hashcode of crn String
	 */
	public int getHashcode(int CRN) {
		//Convert int crn to string 
		String hash = Integer.toString(CRN);
		return hash.hashCode();	
	}
}
