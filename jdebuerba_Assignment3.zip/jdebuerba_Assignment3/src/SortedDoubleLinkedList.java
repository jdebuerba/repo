import java.util.Comparator;
import java.util.ListIterator;

/**
 * Uses the same structure as the BasicDoubleLinkedList(extends) but arranges the elements by increasing order
 *  @author jose de buerba
 *
 * @param <T>
 */
public class SortedDoubleLinkedList<T> extends BasicDoubleLinkedList<T>{
	//Attribute to use Comparator<T> interface
	Comparator<T> comparator;
	
	//Constructor assigns the comparator object
	public SortedDoubleLinkedList(Comparator<T> compareableObject) {
		comparator = compareableObject;
	}
	
	/**
	 * Adds a node, containing an element, into the correct position in the list using compare(obj1,obj2) to measure data size
	 * @param data data being added to the list
	 */
	public void add(T data) {
		//Node being added
		Node newNode = new Node(data);
		//Starting node used to iterate through linked list
		Node currentNode = head;
		
		//Add new Node as head and tail if list is empty
		if(head == null) {
			head = newNode;
			tail = newNode;
		}
		//Assigns new node as the head
		else if(comparator.compare(data, head.data) <= 0) {
			head.prev = newNode;
			newNode.next = head;
			head = newNode;
		}
		//Assigns new node as the tail
		else if(comparator.compare(data, tail.data) >= 0) {
			newNode.prev = tail;
			tail.next = newNode;
			tail = newNode;
		}
		//Iterate through the list and find the correct position for the node
		else {
			while (comparator.compare(data,currentNode.next.data) > 0 && currentNode.next != null) {
				currentNode = currentNode.next;
			}
			newNode = currentNode.prev;
			newNode.next = currentNode;
			currentNode.prev.next = newNode;
			currentNode.prev = newNode;	
		}
	}
	
	/**
	 * Unimplemented method throws UnsupportedOperationException
	 * @exception UnsupportedOperationException
	 */
	public void addToEnd(T data) throws UnsupportedOperationException{
		throw new UnsupportedOperationException("Invalid operation for sorted list.");
	}
	
	/**
	 * Unimplemented method throws UnsupportedOperationException
	 * @exception UnsupportedOperationException
	 */
	public void addToFront(T data) throws UnsupportedOperationException{
		throw new UnsupportedOperationException("Invalid operation for sorted list.");
	}
	
	/**
	 * Returns an iterator from BasicDoubleLinkedList
	 * @return ListIterator<T>
	 */
	public ListIterator<T> iterator(){
		return super.iterator();
	}
	
	/**
	 * Uses the remove method from BasicDoubleLinkedList
	 * @return Node
	 */
	public Node remove(T data,Comparator<T> comparator) {
		return super.remove(data, comparator);
	}
	
}
