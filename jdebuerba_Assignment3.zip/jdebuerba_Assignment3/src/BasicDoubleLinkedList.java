import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;
/**
 * 
 * @author Jose de Buerba
 * Class used to make a doubly unsorted linkedList made up of an inner class that constructs, 
 * nodes, and an iterator. Nodes contain a data value <T>, a pointer to the previous node, and a pointer to the next node.
 * Another inner class that contains methods to iterate through a list.
 * The Linked List structure contains an attribute to count the size of the list, and two ends that
 * keeps track of the first node and last node of the list. 
 * @param <T>
 */
public class BasicDoubleLinkedList<T> extends Object implements Iterable<T>{
	//Linked list attributes
	int size = 0;
	Node head;
	Node tail;
	
	//Default no-arg constructor
	public BasicDoubleLinkedList() {
		head = null;
		tail = null;
	}
	
	/**
	 * Node inner class used to construct an node with data and two pointers
	 * @author jose de buerba
	 *
	 */
	protected class Node{
		//Node attributes
		T data;
		Node prev;
		Node next;
		
		//Node constructor takes in any data(String,int,double,etc..)
		Node(T dataNode){
			this.data = dataNode;
			prev = null;
			next = null;
		}
	}
	
	/**
	 * Creates an new node and adds it to the end of the list
	 * @param data new value contained in node that is passed into list
	 */
	public void addToEnd(T data) {
		//New node containing given data passed from argument 
		Node newNode = new Node(data);
	
		//If list is empty, then new node will be the head node and the tail node
		if(getSize() == 0) {
			head = newNode;
			tail = newNode;
		}
		//If list is not empty, add node to back of the list
		else {
			tail.next = newNode;
			newNode.prev = tail;
			tail = newNode;	
		}
		//Increments the size of the list every time a new node is added
		size++;
	}
	
	/**
	 * Creates a new node and adds it to the front of the list
	 * @param data new value contained in node that is passed into list
	 */
	public void addToFront(T data) {
		//New node containing given data passed from argument 
		Node newNode = new Node(data);
		
		//If list is empty, then new node will be the head node and the tail node
		if(getSize() == 0) {
			head = newNode;
			tail = newNode;
		}
		//If list is not empty, add node to front of the list
		else {
			newNode.next = head;
			head.prev = newNode;
			head = newNode;
		}
		//Increments the size of the list every time a new node is added
		size++;
	}
	
	/**
	 * Retrieves the first data element from the list without removing it
	 * @return data the data inside the first node of the list
	 */
	public T getFirst() {
		if(getSize()== 0) 
			return null;
		else {
			return head.data;
		}
	}
	
	/**
	 * Retrieves the last data element from the list without removing it
	 * @return data the data inside the last node of the list
	 */
	public T getLast() {
		if(getSize()== 0) 
			return null;
		else {
			return tail.data;
		}
	}
	
	/**
	 * Retrieves the length of the list
	 * @return size size of the list
	 */
	public int getSize() {
		return size;
	}
	
	/**
	 * Returns an new iterator for the unsorted linked list
	 */
	@Override
	public ListIterator<T> iterator() {
		// TODO Auto-generated method stub
		return new DoubleLinkedListIterator();
	}
	
	/**
	 * Removes the first instance of the target data from the list by comparing each element 
	 * in the list with the targeted value using the Comparator<T> class
	 * @param targetData the data element to be removed
	 * @param comparator the comparator object to determine equlaity of data elements
	 * @return
	 */
	public Node remove(T targetData, Comparator<T> comparator) {
		//Starting node to be used for traversing the list
		Node currentNode = head;
		
		//Traverse through the list until no more nodes are in the list 
		while(currentNode != null) {
			//Finds the targeted element in the list
			if(comparator.compare(currentNode.data, targetData) == 0) {
				//If the targeted element is in the head node then remove it and shift the head index to next node
				if(currentNode.prev == null) {
					head = currentNode.next;
				}
				//Remove the node and shift all other nodes together
				else {
					currentNode.prev.next = currentNode.next;
				}
				//If the targeted element is in the tail node then remove it and shift the tail index to previous node
				if(currentNode.next == null) {
					tail = currentNode.prev;
				}
				//Shift the nodes together once target is removed
				else {
					currentNode.next.prev = currentNode.prev;
				}
				//Decrement the size of the list once node with data is removed
				size--;
				//return the removed node
				return currentNode;
			}
			//Go to next node
			currentNode = currentNode.next;
		}
		//Return null just in case
		return null;
	}
	
	/**
	 * Retrieves and removes first element in the list
	 * @return data data in the first node
	 */
	public T retrieveFirstElement() {
		//Data to be retrieved
		T firstElement;
		
		//If no elements are in list return null
		if(getSize() == 0) {
			return null;
		}
		//If only one element in list then return it and empty the list
		else if(getSize() == 1) {
			firstElement = getFirst();
			head = null;
			tail = null;
			size--;
			return firstElement;
		}
		//Return the first element and shift position of head
		else {
			firstElement = getFirst();
			head.next.prev = null;
			head = head.next;
			size--;
			return firstElement;
		}
	}
	
	/**
	 * Retrieves and removes last element in the list
	 * @return
	 */
	public T retrieveLastElement() {
		//Data to be retrieved
		T lastElement;
		
		//If no elements are in list return null
		if(getSize()== 0) {
			return null;
		}
		//If only one element in list then return it and empty the list
		else if(getSize()==1) {
			lastElement = getLast();
			head = null;
			tail = null;
			size--;
			return lastElement;
		}
		//Return the first element and shift position of tail
		else {
			lastElement = getLast();
			tail.prev.next = null;
			tail = tail.prev;
			size--;
			return lastElement;
		}
	}
	
	/**
	 * Add all elements of the nodes in the Linked List to an ArrayList for set notation display
	 * @return
	 */
	public ArrayList<T> toArrayList(){
		//ArrayList containing the elements of the nodes
		ArrayList<T> array = new ArrayList<>();
		//Traversing node begins at head
		Node currentNode = head;
		
		//Traverse through linked list until nothing is left
		while(currentNode != null) {
			//Add elements to list
			array.add(currentNode.data);
			//Go to next element in linked list
			currentNode = currentNode.next;
		}
		//return arraylist
		return array;
	}
	
	
	/**
	 * List iterator inner class implements java's ListIterator interface
	 * implements only a few methods of the interface while the rest throw an
	 * UnsupportedOperation Exception
	 * @author jose de buerba
	 *
	 */
	protected class DoubleLinkedListIterator implements Iterator<T>, ListIterator<T>{
		//DoubleLinkedListIterator attributes
		Node currentNode;
		Node previousNode;
		
		//DoubleLinkedListIterator default no arg constructor
		public DoubleLinkedListIterator(){
			previousNode = null;
			currentNode = head;
		}
		
		/**
		 * Checks the list for the next node
		 * @return true if list has next node, false if list has reached end
		 */
		@Override
		public boolean hasNext() {
			return currentNode != null;
		}

		/**
		 * Traverses to the next node on the list
		 * @return data element in node
		 * @throws NoSuchElementException
		 */
		@Override
		public T next() throws NoSuchElementException{
			T data;
			
			//If list contains another node connected to it display its contents
			if(hasNext()) {
				previousNode = currentNode;
				data = previousNode.data;
				currentNode = currentNode.next;
				return data;
			}
			//If no more nodes throw an exception
			else {
				throw new NoSuchElementException();
			}
		}

		/**
		 * Checks the list for the next node
		 * @return true if list has a previous node, false if list has reached the head node
		 */
		@Override
		public boolean hasPrevious() {
			return previousNode != null;
		}

		/**
		 * Traverses to the previous node on the list
		 *  @return data element in node
		 * @throws NoSuchElementException
		 */
		@Override
		public T previous() throws NoSuchElementException {
			T data;
			if(hasPrevious()) {
				currentNode = previousNode;
				data = currentNode.data;
				previousNode = previousNode.prev;
				return data;
			}else {
				throw new NoSuchElementException();
			}
		}

		/**
		 * Method not used, throws an exception
		 * @throws UnsupportedOperationException
		 */
		@Override
		public int nextIndex() throws UnsupportedOperationException {
			// TODO Auto-generated method stub
			throw new UnsupportedOperationException();
		}

		/**
		 * Method not used, throws an exception
		 * @throws UnsupportedOperationException
		 */
		@Override
		public int previousIndex() throws UnsupportedOperationException {
			// TODO Auto-generated method stub
			throw new UnsupportedOperationException();
		}

		/**
		 * Method not used, throws an exception
		 * @throws UnsupportedOperationException
		 */
		@Override
		public void remove() throws UnsupportedOperationException {
			// TODO Auto-generated method stub
			throw new UnsupportedOperationException();
		}

		/**
		 * Method not used, throws an exception
		 * @throws UnsupportedOperationException
		 */
		@Override
		public void set(T arg0) throws UnsupportedOperationException{
			// TODO Auto-generated method stub
			throw new UnsupportedOperationException();
		}

		/**
		 * Method not used, throws an exception
		 * @throws UnsupportedOperationException
		 */
		@Override
		public void add(T arg0) throws UnsupportedOperationException {
			// TODO Auto-generated method stub
			throw new UnsupportedOperationException();
		}
	}
		
}
