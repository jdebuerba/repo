
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
/**
 * Generic Queue class made from an Arraylist
 * @author jdebu
 *
 * @param <T>
 */
public class MyQueue<T> implements QueueInterface<T> {
	
	ArrayList<T> queue;
	int numOfElements = 0;
	int head = 0;
	int tail = 0;
	int size = 0;
	
	
	/**
	 * Default Constructor of MyQueue
	 * Creates a queue of default
	 */
	public MyQueue(){
		this.size = 25;
		queue = new ArrayList<T>(this.size);
		tail = this.size() - 1;
	}
	
	
	/**
	 * Parameterized constructor of MyQueue
	 * @param size size of queue
	 */
	 public MyQueue(int size) {
		this.size = size;
		queue = new ArrayList<T>(this.size);
		tail = this.size - 1;
	}
	
	
	/**
	 * Determines if Queue is empty
	 * @return true if Queue is empty, false if not
	 */
	@Override
	public boolean isEmpty() {
		return numOfElements == 0;
	}

	/**
	 * Determines of the Queue is Full
	 * @return true if Queue is full, false if not
	 */
	@Override
	public boolean isFull() {
		return this.size == numOfElements;
	}

	/**
	 * Deletes and returns the element at the front of the Queue
	 * @return the element at the front of the Queue
	 * @throws QueueUnderflowException if queue is empty
	 */
	@Override
	public T dequeue() throws QueueUnderflowException {
		if(isEmpty()) {
			throw new QueueUnderflowException();
		}else {
			T dequeuedElement;
			dequeuedElement = queue.get(head);
			queue.remove(queue.get(head));
			numOfElements--;
			return dequeuedElement;
		}	
	}

	/**
	 * Returns number of elements in the Queue
	 * @return the number of elements in the Queue
	 */
	@Override
	public int size() {
		return numOfElements;
	}

	/**
	 * Adds an element to the end of the Queue
	 * @param e the element to add to the end of the Queue
	 * @return true if the add was successful
	 * @throws QueueOverflowException if queue is full
	 */
	@Override
	public boolean enqueue(T e) throws QueueOverflowException {
		if(isFull()) {
			throw new QueueOverflowException();
		}
		else {
			queue.add(e);
			numOfElements++;
			return true;
		}
	}
	
	/**
	 * Returns the string representation of the elements in the Queue, 
	 * the beginning of the string is the front of the queue
	 * @return string representation of the Queue with elements
	 */
	@Override
	public String toString() {
		String queue1 = "";
		for(T x : queue) {
			queue1 += x;
		}
		return queue1;
	}
	
	/**
	 * Returns the string representation of the elements in the Queue, the beginning of the string is the front of the queue
	 * Place the delimiter between all elements of the Queue
	 * @return string representation of the Queue with elements separated with the delimiter
	 */
	@Override
	public String toString(String delimiter) {
		String queueString = "";
		for(int i = 0 ; i < queue.size(); i++) {
			queueString += queue.get(i) + delimiter;
		}
		queueString = queueString.substring(0,queue.size()-1);
		return queueString;
	}

	/**
	  * Fills the Queue with the elements of the ArrayList, First element in the ArrayList
	  * is the first element in the Queue
	  * YOU MUST MAKE A COPY OF LIST AND ADD THOSE ELEMENTS TO THE QUEUE, if you use the
	  * list reference within your Queue, you will be allowing direct access to the data of
	  * your Queue causing a possible security breech.
	  * @param list elements to be added to the Queue
	  * @throws QueueOverflowException if queue is full
	 
	  */
	@Override
	public void fill(ArrayList<T> list) {
		ArrayList<T> copy = new ArrayList<>(list);
		for(T x : copy) {
			queue.add(x);
		}
	}

}
