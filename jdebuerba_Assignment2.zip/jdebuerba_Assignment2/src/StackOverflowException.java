
public class StackOverflowException extends Exception{
	public StackOverflowException() {
		super("The stack is full");
	}
	public StackOverflowException(String message) {
		super(message);
	}
}
