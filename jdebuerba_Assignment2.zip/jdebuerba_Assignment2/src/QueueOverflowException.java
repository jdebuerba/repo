
public class QueueOverflowException extends Exception{
	public QueueOverflowException() {
		super("The queue is full");
	}
	public QueueOverflowException(String message) {
		super(message);
	}
}
