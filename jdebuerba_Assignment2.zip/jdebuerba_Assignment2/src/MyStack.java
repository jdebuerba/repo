
import java.util.ArrayList;
import java.util.Collections;

/**
 * Generic Stack class made from Arraylist
 * @author jdebu
 *
 * @param <T>
 */
public class MyStack<T> implements StackInterface<T>{
	
	ArrayList<T> stack;
	int size;
	int numOfElements;
	
	/**
	 * Constructor for MyStack with parameterized argument
	 * @param size size of the stack
	 */
	public MyStack(int size){
		this.size = size;
		stack = new ArrayList<T>(this.size);
	}

	/**
	 * Default constructor for MyStack creates an Arraylist of size 25
	 */
	public MyStack(){
		this.size = 25;
		stack = new ArrayList<T>(this.size);
	}
	
	/**
	 * Determines if Stack is empty
	 * @return true if Stack is empty, false if not
	 */
	@Override
	public boolean isEmpty(){
		return numOfElements == 0;
	}

	/**
	 * Determines if Stack is full
	 * @return true if Stack is full, false if not
	 */
	@Override
	public boolean isFull(){
		return this.size <= numOfElements;
	}

	/**
	 * Deletes and returns the element at the top of the Stack
	 * @return the element at the top of the Stack
	 * @throws StackUnderflowException if stack is empty
	 */
	@Override
	public T pop() throws StackUnderflowException{
		T topElement;
		if(isEmpty()) 
			throw new StackUnderflowException();
		else{
			topElement = stack.get(numOfElements - 1);
			stack.remove(numOfElements - 1);
			numOfElements--;
			return topElement;
		}
	}

	/**
	 * Returns the element at the top of the Stack, does not pop it off the Stack
	 * @return the element at the top of the Stack
	 * @throws StackUnderflowException if stack is empty
	 */
	@Override
	public T top() throws StackUnderflowException{
		T top;
		int topIndex = numOfElements - 1;
		if(isEmpty()) 
			throw new StackUnderflowException();
		else{
			top = stack.get(topIndex);
			return top;
		}
	}

	/**
	 * Number of elements in the Stack
	 * @return the number of elements in the Stack
	 */
	@Override
	public int size(){
		return numOfElements;
	}

	/**
	 * Adds an element to the top of the Stack
	 * @param i the element to add to the top of the Stack
	 * @return true if the add was successful, false if not
	 * @throws StackOverflowException if stack is full
	 */
	@Override
	public boolean push(T e) throws StackOverflowException{
		if(isFull()) 
			throw new StackOverflowException("Stack is full");
		else{
			stack.add(e);
			numOfElements++;
			return true;
		}
	}
	
	/**
	 * Returns the elements of the Stack in a string from bottom to top, the beginning 
	 * of the String is the bottom of the stack
	 * @return an string which represent the Objects in the Stack from bottom to top
	 */
	@Override
	public String toString(){
		String stack1 = "";
		
		for(int i = 0 ; i < stack.size() ; i++){
			stack1 += stack.get(i);
		}
		return stack1;
	}
	
	/**
	 * Returns the string representation of the elements in the Stack, the beginning of the 
	 * string is the bottom of the stack
	 * Place the delimiter between all elements of the Stack
	 * @return string representation of the Stack from bottom to top with elements 
	 * separated with the delimiter
	 */
	@Override
	public String toString(String delimiter){
		String stackString = "";
		for(int i = 0 ; i < stack.size(); i++) {
			stackString += stack.get(i) + delimiter;
		}
		stackString += stackString;
		return stackString;
	}
	
	 /**
	  * Fills the Stack with the elements of the ArrayList, First element in the ArrayList
	  * is the first bottom element of the Stack
	  * YOU MUST MAKE A COPY OF LIST AND ADD THOSE ELEMENTS TO THE STACK, if you use the
	  * list reference within your Stack, you will be allowing direct access to the data of
	  * your Stack causing a possible security breech.
	  * @param list elements to be added to the Stack from bottom to top
	  * @throws StackOverflowException if stack gets full
	  */
	@Override
	public void fill(ArrayList<T> list) {
		ArrayList<T> copy = new ArrayList<>(list);
		for(T x : copy) {
			stack.add(x);
		}
	}

		
	

}