import java.util.Stack;
import java.util.Queue;
import java.util.ArrayList;
import java.util.*;

/**
 * Notation has a method, infixToPostfix, to convert infix notation to 
postfix notation that will take in a string and return a string, a method 
postfixToInfix to convert postfix notation to infix notation that takes in a 
string and return a string, and a method to evaluatePostfix to evaluate the postfix 
expression, it takes in a string and returns a double.

 * @author jdebu
 *
 */
public class Notation{
	 
	/**
	 * Evaluates a postfix expression from a string to a double
	 * @param postfixExpr the postfix expression in String format
	 * @return the evaluation of the postfix expression as a double
	 * @throws InvalidNotationFormatException if the postfix expression format is invalid
	 */
	public static double evaluatePostfixExpression​(String postfixExpr) throws InvalidNotationFormatException{
		//Create MyStack object of type Double
		MyStack<Double> stack = new MyStack<>();
		
		try {
			
		//Iterate through characters of postfixExpression
		for (int i = 0; i < postfixExpr.length(); i++){
			//Character at index position of String postfix 
			char ch = postfixExpr.charAt(i);
			
			//If character is a blank go onto next iteration
			if(Character.isWhitespace(ch)) {
				continue;
			}
			
            //If character is a digit push it into stack
			else if (Character.isDigit(ch)){
                stack.push((double) ((ch - '0'))); 
            }
           
            //If character is an operator multiply, divide, add, or subtract from operands in stack
            else if(operator(ch)){
                //Get second element from the stack
                double num1 = stack.pop();
                
                //Get first element from the stack
                double num2 = stack.pop();

                //Find correct operation, solve, and place solution into stack
                switch(ch){
                	case '*':
                		stack.push(num2 * num1);
                		break;  
                	case '/':
                		stack.push(num2 / num1);
                		break;
                	case '+':
                		stack.push(num2 + num1);
                		break;    
                	case '-':
                		stack.push(num2 - num1);
                		break;   
                }
            }
        }
		//Once expression has been solved return solution from top of stack
		return stack.top();
		
		}catch(StackUnderflowException | StackOverflowException e) {
			e.getMessage();
		}
		return 1;
	}
	
	/**
	 * Convert the Postfix expression to the Infix expression
	 * @param postfix the postfix expression in string format
	 * @return the infix expression in string format
	 * @throws InvalidNotationFormatException if the postfix expression format is invalid
	 */
	public static String convertPostfixToInfix​(String postfix)throws InvalidNotationFormatException{
		//Create MyStack object of type String
		MyStack<String> stack = new MyStack<>();
		//Returning String
		String result = null;
		
		try {
			
		//Iterate through characters of postfix expression
		for (int i = 0; i < postfix.length(); i++) {  
			//Character at index position of String postfix     
			char ch = postfix.charAt(i);
			
			//Execute code if the character is * or / or + or -
			if (operator(ch)){  
				//Pop operands from the stack
				String num1 = stack.pop();  
				String num2 = stack.pop();  
				//Place operator between both operands, a and b, and finally surround it with parentheses
				stack.push('(' + num2 + ch + num1 + ')');  
			} 
			
			//Put operands to stack if no operator is encountered
			else { 
				stack.push("" + ch);  
			}
		}  
		//Pop and return the infix expression 
		result = stack.pop();
		return result;
			
		}catch(StackUnderflowException | StackOverflowException e) {
			e.getMessage();
		}
		
		return result;
	}

	/**
	 * Convert an infix expression into a postfix expression
	 * @param infix the infix expression in string format
	 * @return the postfix expression in string format
	 * @throws InvalidNotationFormatException if the infix expression format is invalid
	 */
	public static String convertInfixToPostfix​(String infix) throws InvalidNotationFormatException{
		//Create MyStack object of type Character
		MyStack<Character> stack = new MyStack<>();
		String postfix = "";
		
		try {
			//Iterate through characters of infix expression
		for(int i = 0 ; i <infix.length() ; i++) {
			//Character at index position of String postfix
			char ch = infix.charAt(i);
			
			//If character is whitespace go onto next iteration
			if(Character.isWhitespace(ch))
				continue;
			
			//If character is letter or digit add to postfix expression
			else if(Character.isLetterOrDigit(ch))
				postfix += (ch);
			
			//If character is left parentheses add to the stack
			else if(ch == '(')
				stack.push(ch);
			
			//If character is right parentheses, iterate and remove through the stack until a left parentheses is found
			else if(ch == ')') {
				while(!stack.isEmpty() && stack.top() != '(') {
					postfix += stack.pop();
				}
				stack.pop();
			}
				
			//If the character is an operator, check which operator has higher precedence and add to the stack or remove once precedence is lower
			else if(operator(ch)) {
				while(!stack.isEmpty() && (precedence(stack.top()) >= precedence(ch))) {
					postfix += stack.pop();
				}
				stack.push(ch);
			}
		}
			//Append the rest of the Stack to the String
			while(!stack.isEmpty()) {
				postfix += stack.pop();
			}
			
		}catch(StackUnderflowException | StackOverflowException e) {
			e.getMessage();
		}
			
		//Return new postfix expression
		return postfix;
	}
	
	/**
	 * Returns true if given character is an operator(*,/,+,-) and returns false if not operator
	 * @param op character tested if is an operator
	 * @return true if operator or false if not
	 */
	private static boolean operator(char op)   
	{  
	if (op == '*' || op == '/' || op == '+' || op == '-')  
		return true;  
	else
		return false;  
	} 
	
	/**
	 * Checks character for level of precedence (Pemdas)
	 * @param op character tested for priority
	 * @return return 1 if character is a '+' or '-', return 2 if character is '*' or '/', and default returns -1 if not an operator
	 */
	public static int precedence(char op) {
		switch(op) {
		case '*':
		case '/':
			return 2;
		case '+':
		case '-':
			return 1;
		default:
			return -1;
		}
	}
}