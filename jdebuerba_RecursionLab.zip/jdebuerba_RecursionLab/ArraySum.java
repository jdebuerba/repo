package package1;

public class ArraySum {

	public int sumOfArray (Integer[] a,int index) {
		int sum = 0;
		
		//Return 0 if index reaches less than 0
		if(index < 0) {
			return 0;
		}else {
		//Adds the element to the sum of the array
		sum += a[index] + sumOfArray(a, index-1);
		return sum;
		}
	}
}
