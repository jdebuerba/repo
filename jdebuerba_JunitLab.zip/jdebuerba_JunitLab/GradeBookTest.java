import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class GradeBookTest {
	private GradeBook gradebook1;
	private GradeBook gradebook2;

	@Before
	public void setUp() throws Exception {
		gradebook1 = new GradeBook(5);
		gradebook2 = new GradeBook(5);
		gradebook1.addScore(90.0);
		gradebook1.addScore(80.0);
		gradebook2.addScore(100.0);
		gradebook2.addScore(90.0);
		
	}

	@After
	public void tearDown() throws Exception {
		gradebook1 = null;
		gradebook2 = null;
	}

	@Test
	public void testAddScore() {
		assertTrue((gradebook1.toString()).equals("90.0 80.0 "));
		assertTrue((gradebook2.toString()).equals("100.0 90.0 "));
		assertEquals(2, gradebook1.getScoreSize(), 0.001);
		assertEquals(2, gradebook2.getScoreSize(), 0.001);
	}

	@Test
	public void testSum() {
		assertEquals(170.0, gradebook1.sum(), 0.0001);
		assertEquals(190.0, gradebook2.sum(), 0.0001);
	}

	@Test
	public void testMinimum() {
		assertEquals(80.0, gradebook1.minimum(), 0.001);
		assertEquals(90.0, gradebook2.minimum(), 0.001);
	}

	@Test
	public void testFinalScore() {
		assertEquals(90.0, gradebook1.finalScore(), 0.0001);
		assertEquals(100.0, gradebook2.finalScore(), 0.0001);
	}

	@Test
	public void testGetScoreSize() {
		fail("Not yet implemented");
	}

	@Test
	public void testToString() {
		fail("Not yet implemented");
	}

}
